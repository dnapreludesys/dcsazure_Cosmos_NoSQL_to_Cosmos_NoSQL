import azure.functions as func
import azure.durable_functions as df
import logging
import json
import pandas as pd
import uuid
import time
import gc
from azure.cosmos import CosmosClient
from azure.storage.filedatalake import DataLakeServiceClient
from io import StringIO
from collections import deque
from datetime import datetime
from typing import Dict, List, Tuple, Optional, Iterator
from azure.core.exceptions import ClientAuthenticationError, ResourceNotFoundError

app = df.DFApp(http_auth_level=func.AuthLevel.ANONYMOUS)


class CosmosMetadata:
    @staticmethod
    def get_throughput_info(database, container_name: str) -> Dict:
        try:
            container = database.get_container_client(container_name)
            try:
                offer = container.read_offer()
                if offer:
                    is_autoscale = 'maximumThroughput' in offer.get('content', {})
                    throughput = (offer['content'].get('maximumThroughput')
                                  or offer['content'].get('throughput', 400))
                    return {
                        'level': 'container',
                        'throughput': throughput,
                        'is_autoscale': is_autoscale
                    }
            except Exception:
                pass

            try:
                db_offer = database.read_offer()
                if db_offer:
                    is_autoscale = 'maximumThroughput' in db_offer.get('content', {})
                    throughput = (db_offer['content'].get('maximumThroughput')
                                  or db_offer['content'].get('throughput', 400))
                    return {
                        'level': 'database',
                        'throughput': throughput,
                        'is_autoscale': is_autoscale
                    }
            except Exception:
                pass

            return {'level': 'unknown', 'throughput': 400, 'is_autoscale': False}

        except Exception:
            return {'level': 'unknown', 'throughput': 400, 'is_autoscale': False}

    @staticmethod
    def get_partition_key_paths(container) -> str:
        try:
            properties = container.read()
            pk_definition = properties.get('partitionKey', {})
            paths = pk_definition.get('paths', [])
            return paths if paths else []
        except Exception:
            return []
        
    @staticmethod
    def discover_partition_values(container, pk_path: str, max_sample: int = 1000) -> List:
        try:
            pk_field = "c." + pk_path.strip("/").replace("/", ".")
            try:
                query = f"SELECT DISTINCT VALUE {pk_field} FROM c"
                items = list(container.query_items(
                    query=query,
                    enable_cross_partition_query=True,
                    max_item_count=max_sample
                ))
                return [v for v in items if v is not None]
            except Exception:
                pass

            query = f"SELECT {pk_field} as pk FROM c"
            items = list(container.query_items(
                query=query,
                enable_cross_partition_query=True,
                max_item_count=max_sample
            ))
            return list(set([item.get('pk') for item in items if item.get('pk') is not None]))

        except Exception:
            return []


def flatten_dict(doc, parent_key="", sep="."):
    items = {}
    for k, v in doc.items():
        new_key = f"{parent_key}{sep}{k}" if parent_key else k
        if isinstance(v, dict):
            items.update(flatten_dict(v, new_key, sep=sep))
        else:
            items[new_key] = v
    return items


class TokenBucketRUManager:
    def __init__(self, throughput: int, reserve_percent: float = 0.2):
        self.max_rus_per_second = int(throughput * (1 - reserve_percent))
        self.tokens = float(self.max_rus_per_second)
        self.last_refill = time.time()
        self.total_consumed = 0.0
        self.operations_count = 0

    def _refill_tokens(self):
        now = time.time()
        elapsed = now - self.last_refill
        if elapsed > 0:
            refill_amount = elapsed * self.max_rus_per_second
            self.tokens = min(self.max_rus_per_second, self.tokens + refill_amount)
            self.last_refill = now

    def consume(self, ru_charge: float):
        self._refill_tokens()
        if ru_charge > self.tokens:
            deficit = ru_charge - self.tokens
            wait_time = deficit / self.max_rus_per_second
            time.sleep(wait_time)
            self._refill_tokens()

        self.tokens -= ru_charge
        self.total_consumed += ru_charge
        self.operations_count += 1

    def get_stats(self) -> Dict:
        avg_ru = self.total_consumed / self.operations_count if self.operations_count > 0 else 0
        return {
            'total_rus_consumed': round(self.total_consumed, 2),
            'operations_count': self.operations_count,
            'avg_ru_per_operation': round(avg_ru, 2),
            'current_tokens': round(self.tokens, 2)
        }


class CosmosRetryStrategy:
    def __init__(self, max_retries: int = 5, base_delay: float = 0.1, max_delay: float = 60.0):
        self.max_retries = max_retries
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.retry_429_count = 0

    def execute_with_retry(self, operation, operation_name: str = "operation"):
        import random
        for attempt in range(self.max_retries + 1):
            try:
                result, headers = operation()
                return result, headers
            except Exception as e:
                error_msg = str(e)
                is_429 = "429" in error_msg or "RequestRateTooLarge" in error_msg

                if is_429:
                    self.retry_429_count += 1
                    retry_after = self._extract_retry_after(e)
                    if attempt < self.max_retries:
                        wait_time = retry_after if retry_after else self._calculate_backoff(attempt)
                        jitter = random.uniform(0, 0.1 * wait_time)
                        total_wait = wait_time + jitter
                        time.sleep(total_wait)
                        continue

                if attempt == self.max_retries:
                    raise

                wait_time = self._calculate_backoff(attempt)
                time.sleep(wait_time)

    def _extract_retry_after(self, exception) -> Optional[float]:
        try:
            if hasattr(exception, 'headers'):
                retry_ms = exception.headers.get('x-ms-retry-after-ms')
                if retry_ms:
                    return float(retry_ms) / 1000.0
        except Exception:
            pass
        return None

    def _calculate_backoff(self, attempt: int) -> float:
        return min(self.base_delay * (2 ** attempt), self.max_delay)

    def get_stats(self) -> Dict:
        return {'total_429_retries': self.retry_429_count}


class StreamingCosmosReader:
    def __init__(self, container, pk_path: Optional[str], pk_values: Optional[List], 
                 batch_size: int, throughput: int = 400):
        self.container = container
        self.pk_path = pk_path
        self.pk_values = pk_values
        self.batch_size = batch_size
        self.ru_manager = TokenBucketRUManager(throughput, reserve_percent=0.2)
        self.retry_strategy = CosmosRetryStrategy(max_retries=5)

    def _extract_ru_charge(self) -> float:
        """Extract RU charge from last response headers."""
        try:
            headers = self.container.client_connection.last_response_headers
            return float(headers.get('x-ms-request-charge', 0))
        except Exception:
            return 5.0  # Default estimate if unable to extract

    def stream_documents(self) -> Iterator[List[Dict]]:
        """
        Generator that yields batches of documents from Cosmos DB.
        Only keeps one batch in memory at a time.
        """
        if self.pk_values:
            # Stream partitions one at a time
            for pk_value in self.pk_values:
                yield from self._stream_partition(pk_value)
        else:
            # Stream all documents with cross-partition query
            yield from self._stream_all_documents()

    def _stream_partition(self, pk_value) -> Iterator[List[Dict]]:
        """Stream documents from a single partition in batches with RU management."""
        key_path_parts = [k for k in self.pk_path.strip("/").split("/") if k]
        cosmos_key_path = "c." + ".".join(key_path_parts)
        
        query = f"SELECT * FROM c WHERE {cosmos_key_path} = @value"
        
        def _execute_query():
            query_iterator = self.container.query_items(
                query=query,
                parameters=[{"name": "@value", "value": pk_value}],
                enable_cross_partition_query=True,
                max_item_count=self.batch_size
            )
            return query_iterator, None
        
        try:
            query_iterator, _ = self.retry_strategy.execute_with_retry(
                _execute_query,
                f"stream_partition_{pk_value}"
            )
        except Exception as e:
            logging.error(f"Failed to query partition {pk_value}: {str(e)}")
            return
        
        batch = []
        for page in query_iterator.by_page():
            items = list(page)
            
            # Track and manage RU consumption
            ru_charge = self._extract_ru_charge()
            self.ru_manager.consume(ru_charge)
            
            for item in items:
                batch.append(item)
                if len(batch) >= self.batch_size:
                    yield batch
                    batch = []
                    gc.collect()
        
        if batch:  # Yield remaining items
            yield batch
            gc.collect()

    def _stream_all_documents(self) -> Iterator[List[Dict]]:
        """Stream all documents in batches using cross-partition query with RU management."""
        query = "SELECT * FROM c"
        
        def _execute_query():
            query_iterator = self.container.query_items(
                query=query,
                enable_cross_partition_query=True,
                max_item_count=self.batch_size
            )
            return query_iterator, None
        
        try:
            query_iterator, _ = self.retry_strategy.execute_with_retry(
                _execute_query,
                "stream_all_documents"
            )
        except Exception as e:
            logging.error(f"Failed to query all documents: {str(e)}")
            return
        
        batch = []
        for page in query_iterator.by_page():
            items = list(page)
            
            # Track and manage RU consumption
            ru_charge = self._extract_ru_charge()
            self.ru_manager.consume(ru_charge)
            
            for item in items:
                batch.append(item)
                if len(batch) >= self.batch_size:
                    yield batch
                    batch = []
                    gc.collect()
        
        if batch:
            yield batch
            gc.collect()

    def get_stats(self) -> Dict:
        """Get RU consumption and retry statistics."""
        ru_stats = self.ru_manager.get_stats()
        retry_stats = self.retry_strategy.get_stats()
        return {**ru_stats, **retry_stats}


def extract_arrays_iterative_optimized(doc, doc_index: int = 0, total_docs: int = 0):

    parent_fields = {}
    child_tables = {}
    root_rid = doc.get("_rid") or str(uuid.uuid4())
    doc["_rid"] = root_rid

    queue = deque()

    def flatten_no_arrays(d, parent=""):
        flat = {}
        for k, v in d.items():
            key = f"{parent}.{k}" if parent else k
            if isinstance(v, list):
                flat[key] = v
            elif isinstance(v, dict):
                flat.update(flatten_no_arrays(v, key))
            else:
                flat[key] = v
        return flat

    flat_root = flatten_no_arrays(doc)

    for key, value in flat_root.items():
        if not isinstance(value, list):
            parent_fields[key] = value
            continue

        primitive_items = [v for v in value if not isinstance(v, dict)]
        dict_items = [v for v in value if isinstance(v, dict)]

        if primitive_items and not dict_items:
            parent_fields[key] = value
            continue

        for item in dict_items:
            item_rid = str(uuid.uuid4())
            item["_rid"] = item_rid
            item["_parent_rid"] = root_rid
            table_name = key
            queue.append((item, table_name, root_rid))

    batch_size = 100
    current_batch = {}

    while queue:
        current, table_name, parent_rid = queue.popleft()
        flat = flatten_no_arrays(current)
        row = {"_rid": current["_rid"], "_parent_rid": parent_rid}

        for key, value in flat.items():
            if not isinstance(value, list):
                row[key] = value
                continue

            primitive_items = [v for v in value if not isinstance(v, dict)]
            dict_items = [v for v in value if isinstance(v, dict)]

            if primitive_items and not dict_items:
                row[key] = value
                continue

            for item in dict_items:
                item_rid = str(uuid.uuid4())
                item["_rid"] = item_rid
                item["_parent_rid"] = current["_rid"]
                nested_table_name = f"{table_name}.{key.split('.')[-1] if '.' in key else key}"
                queue.append((item, nested_table_name, current["_rid"]))

        if table_name not in current_batch:
            current_batch[table_name] = []
        current_batch[table_name].append(row)

        if len(current_batch.get(table_name, [])) >= batch_size:
            if table_name not in child_tables:
                child_tables[table_name] = []
            child_tables[table_name].append(pd.DataFrame(current_batch[table_name]))
            current_batch[table_name] = []

    for table_name, rows in current_batch.items():
        if rows:
            if table_name not in child_tables:
                child_tables[table_name] = []
            child_tables[table_name].append(pd.DataFrame(rows))

    final_children = {}
    for k, v in child_tables.items():
        try:
            final_children[k] = pd.concat(v, ignore_index=True)
        except ValueError:
            final_children[k] = pd.DataFrame(v)

    return parent_fields, final_children


def clean_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or df.empty:
        return pd.DataFrame()

    def fix_value(val):
        if val is None:
            return None
        if isinstance(val, (str, int, float, bool)):
            return val
        if isinstance(val, list) and all(not isinstance(i, dict) for i in val):
            return val
        if isinstance(val, dict):
            return None
        if isinstance(val, list) and any(isinstance(i, dict) for i in val):
            return None
        try:
            return str(val)
        except Exception:
            return None

    for col in df.columns:
        df[col] = df[col].apply(fix_value)

    return df


def upload_csv_to_adls(service_client, file_system, directory, file_name, df, mode='write'):
    
    df = clean_dataframe(df)
    if df is None or df.empty:
        logging.warning(f"Skipping upload for {file_name} - empty dataframe")
        return

    fs_client = service_client.get_file_system_client(file_system)
    dir_segments = directory.strip("/").split("/") if directory else []
    curr = ""

    for seg in dir_segments:
        curr = f"{curr}/{seg}" if curr else seg
        try:
            fs_client.get_directory_client(curr).create_directory()
        except Exception:
            pass

    dir_client = fs_client.get_directory_client(directory)

    df_out = df.copy()

    def serialize_cell(v):
        if v is None:
            return ""
        if isinstance(v, list):
            try:
                return json.dumps(v, ensure_ascii=False)
            except Exception:
                return str(v)
        return v

    for col in df_out.columns:
        df_out[col] = df_out[col].apply(serialize_cell)

    try:
        file_client = dir_client.get_file_client(file_name)
        
        if mode == 'write':
            # Overwrite mode - delete and recreate
            try:
                file_client.delete_file()
            except Exception:
                pass
            
            csv_buffer = StringIO()
            df_out.to_csv(csv_buffer, index=False, sep="|", header=True)
            content = csv_buffer.getvalue()
            
            file_client = dir_client.create_file(file_name)
            file_client.append_data(content, offset=0, length=len(content))
            file_client.flush_data(len(content))
            logging.info(f"Wrote {len(df)} rows to {file_name}")
            
        else:  # append mode
            file_exists = False
            current_size = 0
            
            try:
                properties = file_client.get_file_properties()
                current_size = properties.size
                file_exists = True
            except Exception:
                file_exists = False
            
            # Generate CSV content (with or without header based on file existence)
            csv_buffer = StringIO()
            include_header = not file_exists
            df_out.to_csv(csv_buffer, index=False, sep="|", header=include_header)
            content = csv_buffer.getvalue()
            
            if not file_exists:
                # Create new file
                file_client = dir_client.create_file(file_name)
                current_size = 0
            
            # Append data
            file_client.append_data(content, offset=current_size, length=len(content))
            file_client.flush_data(current_size + len(content))
            logging.info(f"Appended {len(df)} rows to {file_name} (total size: {current_size + len(content)} bytes)")
            
    except Exception as e:
        logging.error(f"Upload failed for {file_name}: {str(e)}")
        raise


def validate_cosmos_connection(cosmos_url, cosmos_key, cosmos_db, cosmos_container):
    try:
        client = CosmosClient(cosmos_url, credential=cosmos_key)
        database = client.get_database_client(cosmos_db)
        database.read()

        container = database.get_container_client(cosmos_container)
        container.read()

        return client, database, container

    except ClientAuthenticationError:
        raise ValueError("Cosmos authentication failed. Invalid cosmos_key or endpoint.")
    except ResourceNotFoundError as e:
        raise ValueError(f"Cosmos resource not found: {str(e)}")
    except Exception as e:
        raise ValueError(f"Cosmos connection validation failed: {str(e)}")


def validate_adls_connection(adls_account_name, adls_account_key, adls_file_system):
    try:
        service_client = DataLakeServiceClient(
            account_url=f"https://{adls_account_name}.dfs.core.windows.net",
            credential=adls_account_key
        )

        fs_client = service_client.get_file_system_client(adls_file_system)
        list(fs_client.get_paths(path="", max_results=1))

        return service_client

    except ClientAuthenticationError:
        raise ValueError("ADLS authentication failed. Invalid account key or account name.")
    except ResourceNotFoundError:
        raise ValueError(f"ADLS filesystem '{adls_file_system}' does not exist.")
    except Exception as e:
        raise ValueError(f"ADLS connection validation failed: {str(e)}")


@app.activity_trigger(input_name="params")
def process_cosmos_to_adls_activity(params: dict):
    start_time = datetime.utcnow()

    try:
        cosmos_url = params.get("cosmos_url")
        cosmos_key = params.get("cosmos_key")
        cosmos_db = params.get("cosmos_db")
        cosmos_container = params.get("cosmos_container")
        partition_key_path = params.get("partition_key_path")
        partition_key_values = params.get("partition_key_value")
        adls_account_name = params.get("adls_account_name")
        adls_account_key = params.get("adls_account_key")
        adls_file_system = params.get("adls_file_system")
        adls_directory = params.get("adls_directory", "")
        
        # Batch size parameter with default
        batch_size = params.get("batch_size", 500)
        
        # Validate batch_size
        try:
            batch_size = int(batch_size)
            if batch_size < 1:
                batch_size = 500
                logging.warning(f"Invalid batch_size, using default: 500")
        except (ValueError, TypeError):
            batch_size = 500
            logging.warning(f"Invalid batch_size format, using default: 500")

        # Separate files per batch parameter
        separate_files_per_batch = params.get("separate_files_per_batch", False)

        logging.info(f"Processing with batch_size: {batch_size}")
        logging.info(f"File strategy: {'Separate CSV per batch' if separate_files_per_batch else 'Consolidated CSV (append mode)'}")

        # -------- FAIL FAST: REQUIRED INPUTS --------
        missing = [
            k for k, v in {
                "cosmos_url": cosmos_url,
                "cosmos_key": cosmos_key,
                "cosmos_db": cosmos_db,
                "cosmos_container": cosmos_container,
                "adls_account_name": adls_account_name,
                "adls_account_key": adls_account_key,
                "adls_file_system": adls_file_system
            }.items() if not v
        ]

        if missing:
            raise ValueError(f"Missing required parameters: {missing}")

        # -------- FAIL FAST: CONNECTION VALIDATION --------
        client, database, container = validate_cosmos_connection(
            cosmos_url, cosmos_key, cosmos_db, cosmos_container
        )

        service_client = validate_adls_connection(
            adls_account_name, adls_account_key, adls_file_system
        )

        has_pk_path = bool(partition_key_path)
        has_pk_values = bool(partition_key_values)

        if has_pk_path != has_pk_values:
            raise ValueError(
                "Invalid partition configuration: "
                "Both 'partition_key_path' AND 'partition_key_value' must be provided together."
            )

        user_provided_both = has_pk_path and has_pk_values

        # -------- SETUP PARTITION CONFIGURATION --------
        if user_provided_both:
            pk_path = partition_key_path

            if isinstance(partition_key_values, str):
                try:
                    pk_values = json.loads(partition_key_values)
                except Exception:
                    pk_values = [partition_key_values]
            elif isinstance(partition_key_values, list):
                pk_values = partition_key_values
            else:
                pk_values = [partition_key_values]

            if not pk_values:
                raise ValueError("partition_key_value was provided but is empty.")

            # Get all partition key paths from the container (can be up to 3)
            actual_pk_paths = CosmosMetadata.get_partition_key_paths(container)
            
            # Validate that user-provided path exists in the container's partition keys
            if pk_path not in actual_pk_paths:
                raise ValueError(
                    f"Provided partition_key_path '{pk_path}' does not match any of the "
                    f"container's partition key paths: {actual_pk_paths}"
                )

            discovered_values = CosmosMetadata.discover_partition_values(container, pk_path)
            invalid_values = set(pk_values) - set(discovered_values)

            if invalid_values:
                raise ValueError(
                    f"Invalid partition_key_value(s): {list(invalid_values)} "
                    f"do not exist in container."
                )
        else:
            # Auto-detect partition configuration - use the first (primary) partition key
            pk_paths = CosmosMetadata.get_partition_key_paths(container)
            if pk_paths:
                pk_path = pk_paths[0]  # Use primary partition key for auto-detection
                pk_values = CosmosMetadata.discover_partition_values(container, pk_path)
            else:
                pk_path = None
                pk_values = None

        # -------- STREAMING BATCH PROCESSING --------
        export_dir = f"{adls_directory}/{cosmos_container}" if adls_directory else cosmos_container
        
        # Get throughput info for RU management
        throughput_info = CosmosMetadata.get_throughput_info(database, cosmos_container)
        throughput = throughput_info.get('throughput', 400)
        
        logging.info(f"Detected throughput: {throughput} RU/s (Level: {throughput_info.get('level', 'unknown')})")
        
        # Create streaming reader with RU management - NO documents loaded into memory yet
        streaming_reader = StreamingCosmosReader(
            container=container,
            pk_path=pk_path,
            pk_values=pk_values,
            batch_size=batch_size,
            throughput=throughput
        )
        
        docs_processed = 0
        total_parent_rows = 0
        child_table_names = set()
        batch_num = 0
        
        logging.info(f"Starting streaming batch processing with batch_size: {batch_size}")
        
        # Stream documents in batches - only one batch in memory at a time
        for batch_docs in streaming_reader.stream_documents():
            batch_num += 1
            batch_start = docs_processed
            batch_end = batch_start + len(batch_docs)
            
            logging.info(f"Processing batch {batch_num}: docs {batch_start+1} to {batch_end}")
            
            # Process batch
            parent_records = []
            batch_child_tables = {}
            
            for idx, doc in enumerate(batch_docs):
                parent, children = extract_arrays_iterative_optimized(
                    doc, 
                    batch_start + idx + 1, 
                    batch_start + len(batch_docs)
                )
                parent_records.append(parent)
                
                for arr_name, df in children.items():
                    batch_child_tables.setdefault(arr_name, []).append(df)
            
            # Convert parent to DataFrame
            parent_df = pd.DataFrame(parent_records)
            total_parent_rows += len(parent_df)
            
            # Determine file naming and mode
            if separate_files_per_batch:
                parent_file_name = f"{cosmos_container}_batch_{batch_num:03d}.csv"
                mode = 'write'
            else:
                parent_file_name = f"{cosmos_container}.csv"
                mode = 'append' if batch_num > 1 else 'write'
            
            # Upload parent
            upload_csv_to_adls(
                service_client,
                adls_file_system,
                export_dir,
                parent_file_name,
                parent_df,
                mode
            )
            
            # Merge and upload child tables
            for arr_name, df_list in batch_child_tables.items():
                child_table_names.add(arr_name)
                
                try:
                    merged_df = pd.concat(df_list, ignore_index=True)
                except ValueError:
                    merged_df = pd.DataFrame(df_list)
                
                merged_df = clean_dataframe(merged_df)
                
                if merged_df is not None and not merged_df.empty:
                    path_parts = arr_name.split(".")
                    final_dir = f"{export_dir}/{'/'.join(path_parts)}"
                    
                    if separate_files_per_batch:
                        file_name = f"{path_parts[-1]}_batch_{batch_num:03d}.csv"
                        child_mode = 'write'
                    else:
                        file_name = f"{path_parts[-1]}.csv"
                        child_mode = mode
                    
                    upload_csv_to_adls(
                        service_client,
                        adls_file_system,
                        final_dir,
                        file_name,
                        merged_df,
                        child_mode
                    )
            
            docs_processed += len(batch_docs)
            
            # CRITICAL: Free memory after each batch
            del parent_records
            del batch_child_tables
            del parent_df
            del batch_docs
            
            # Force garbage collection
            gc.collect()
            
            logging.info(f"Batch {batch_num} complete: {docs_processed} total docs processed, memory freed")

        if docs_processed == 0:
            return {"status": "success", "message": "No documents found.", "docs_processed": 0}

        # Get RU and retry statistics
        streaming_stats = streaming_reader.get_stats()
        
        duration = (datetime.utcnow() - start_time).total_seconds()

        return {
            "status": "success",
            "docs_processed": docs_processed,
            "parent_rows": total_parent_rows,
            "child_tables_created": len(child_table_names),
            "batch_size": batch_size,
            "batches_processed": batch_num,
            "separate_files_per_batch": separate_files_per_batch,
            "duration_seconds": round(duration, 2),
            "auto_detected": not user_provided_both,
            "partition_count": len(pk_values) if pk_values else 0,
            "throughput_ru_per_sec": throughput,
            "total_rus_consumed": streaming_stats.get('total_rus_consumed', 0),
            "avg_ru_per_operation": streaming_stats.get('avg_ru_per_operation', 0),
            "total_429_retries": streaming_stats.get('total_429_retries', 0)
        }

    except Exception as e:
        logging.error(f"Activity failed: {str(e)}", exc_info=True)
        return {"status": "error", "message": str(e)}


@app.orchestration_trigger(context_name="context")
def cosmos_to_adls_orchestrator(context: df.DurableOrchestrationContext):
    params = context.get_input()
    result = yield context.call_activity("process_cosmos_to_adls_activity", params)
    return result


@app.route(route="Cosmos_to_ADLS", methods=["POST"])
@app.durable_client_input(client_name="client")
async def cosmos_to_adls_http_start(req: func.HttpRequest, client) -> func.HttpResponse:
    try:
        body = req.get_json()
        instance_id = await client.start_new("cosmos_to_adls_orchestrator", None, body)
        return client.create_check_status_response(req, instance_id)
    except Exception as e:
        return func.HttpResponse(f"Error: {str(e)}", status_code=500)