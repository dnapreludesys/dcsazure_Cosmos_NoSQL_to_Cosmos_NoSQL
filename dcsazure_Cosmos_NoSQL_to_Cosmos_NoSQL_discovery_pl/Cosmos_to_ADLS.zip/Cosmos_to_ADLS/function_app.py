import azure.functions as func
import azure.durable_functions as df
import logging
import json
import pandas as pd
import uuid
import time
from azure.cosmos import CosmosClient
from azure.storage.filedatalake import DataLakeServiceClient
from io import StringIO
from collections import deque
from datetime import datetime
from typing import Dict, List, Tuple, Optional

app = df.DFApp(http_auth_level=func.AuthLevel.ANONYMOUS)


class CosmosMetadata:
    @staticmethod
    def get_throughput_info(database, container_name: str) -> Dict:
        try:
            container = database.get_container_client(container_name)
            try:
                offer = container.read_offer()
                if offer:
                    is_autoscale = 'maximumThroughput' in offer.get('content', {})
                    throughput = (offer['content'].get('maximumThroughput')
                                  or offer['content'].get('throughput', 400))
                    return {
                        'level': 'container',
                        'throughput': throughput,
                        'is_autoscale': is_autoscale
                    }
            except Exception:
                pass

            try:
                db_offer = database.read_offer()
                if db_offer:
                    is_autoscale = 'maximumThroughput' in db_offer.get('content', {})
                    throughput = (db_offer['content'].get('maximumThroughput')
                                  or db_offer['content'].get('throughput', 400))
                    return {
                        'level': 'database',
                        'throughput': throughput,
                        'is_autoscale': is_autoscale
                    }
            except Exception:
                pass

            return {'level': 'unknown', 'throughput': 400, 'is_autoscale': False}

        except Exception:
            return {'level': 'unknown', 'throughput': 400, 'is_autoscale': False}

    @staticmethod
    def get_partition_key_path(container) -> str:
        try:
            properties = container.read()
            pk_definition = properties.get('partitionKey', {})
            paths = pk_definition.get('paths', [])
            if paths:
                return paths[0]
            return None
        except Exception:
            return None

    @staticmethod
    def discover_partition_values(container, pk_path: str, max_sample: int = 1000) -> List:
        try:
            pk_field = "c." + pk_path.strip("/").replace("/", ".")
            try:
                query = f"SELECT DISTINCT VALUE {pk_field} FROM c"
                items = list(container.query_items(
                    query=query,
                    enable_cross_partition_query=True,
                    max_item_count=max_sample
                ))
                return [v for v in items if v is not None]
            except Exception:
                pass

            query = f"SELECT {pk_field} as pk FROM c"
            items = list(container.query_items(
                query=query,
                enable_cross_partition_query=True,
                max_item_count=max_sample
            ))
            return list(set([item.get('pk') for item in items if item.get('pk') is not None]))

        except Exception:
            return []


def flatten_dict(doc, parent_key="", sep="."):
    items = {}
    for k, v in doc.items():
        new_key = f"{parent_key}{sep}{k}" if parent_key else k
        if isinstance(v, dict):
            items.update(flatten_dict(v, new_key, sep=sep))
        else:
            items[new_key] = v
    return items


class TokenBucketRUManager:
    def __init__(self, throughput: int, reserve_percent: float = 0.2):
        self.max_rus_per_second = int(throughput * (1 - reserve_percent))
        self.tokens = float(self.max_rus_per_second)
        self.last_refill = time.time()
        self.total_consumed = 0.0
        self.operations_count = 0

    def _refill_tokens(self):
        now = time.time()
        elapsed = now - self.last_refill
        if elapsed > 0:
            refill_amount = elapsed * self.max_rus_per_second
            self.tokens = min(self.max_rus_per_second, self.tokens + refill_amount)
            self.last_refill = now

    def consume(self, ru_charge: float):
        self._refill_tokens()
        if ru_charge > self.tokens:
            deficit = ru_charge - self.tokens
            wait_time = deficit / self.max_rus_per_second
            time.sleep(wait_time)
            self._refill_tokens()

        self.tokens -= ru_charge
        self.total_consumed += ru_charge
        self.operations_count += 1

    def get_stats(self) -> Dict:
        avg_ru = self.total_consumed / self.operations_count if self.operations_count > 0 else 0
        return {
            'total_rus_consumed': round(self.total_consumed, 2),
            'operations_count': self.operations_count,
            'avg_ru_per_operation': round(avg_ru, 2),
            'current_tokens': round(self.tokens, 2)
        }


class CosmosRetryStrategy:
    def __init__(self, max_retries: int = 5, base_delay: float = 0.1, max_delay: float = 60.0):
        self.max_retries = max_retries
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.retry_429_count = 0

    def execute_with_retry(self, operation, operation_name: str = "operation"):
        import random
        for attempt in range(self.max_retries + 1):
            try:
                result, headers = operation()
                return result, headers
            except Exception as e:
                error_msg = str(e)
                is_429 = "429" in error_msg or "RequestRateTooLarge" in error_msg

                if is_429:
                    self.retry_429_count += 1
                    retry_after = self._extract_retry_after(e)
                    if attempt < self.max_retries:
                        wait_time = retry_after if retry_after else self._calculate_backoff(attempt)
                        jitter = random.uniform(0, 0.1 * wait_time)
                        total_wait = wait_time + jitter
                        time.sleep(total_wait)
                        continue

                if attempt == self.max_retries:
                    raise

                wait_time = self._calculate_backoff(attempt)
                time.sleep(wait_time)

    def _extract_retry_after(self, exception) -> Optional[float]:
        try:
            if hasattr(exception, 'headers'):
                retry_ms = exception.headers.get('x-ms-retry-after-ms')
                if retry_ms:
                    return float(retry_ms) / 1000.0
        except Exception:
            pass
        return None

    def _calculate_backoff(self, attempt: int) -> float:
        return min(self.base_delay * (2 ** attempt), self.max_delay)

    def get_stats(self) -> Dict:
        return {'total_429_retries': self.retry_429_count}


class OptimizedParallelCosmosReader:
    def __init__(self, container, throughput: int, partition_values: List):
        self.container = container
        self.partition_values = partition_values
        self.ru_manager = TokenBucketRUManager(throughput, reserve_percent=0.2)
        self.retry_strategy = CosmosRetryStrategy(max_retries=5)
        available_rus = int(throughput * 0.8)
        self.max_parallel = max(1, min(len(partition_values), available_rus // 100))

    def _extract_ru_charge(self, headers) -> float:
        try:
            return float(headers.get('x-ms-request-charge', 0))
        except Exception:
            return 5.0

    def read_partition(self, pk_value, pk_path: str) -> Tuple[List, Dict]:
        start_time = time.time()
        key_path_parts = [k for k in pk_path.strip("/").split("/") if k]
        cosmos_key_path = "c." + ".".join(key_path_parts)

        all_items = []
        total_rus = 0.0
        page_count = 0

        def _execute_query():
            query = f"SELECT * FROM c WHERE {cosmos_key_path} = @value"
            query_iterator = self.container.query_items(
                query=query,
                parameters=[{"name": "@value", "value": pk_value}],
                enable_cross_partition_query=True
            )
            return query_iterator, None

        try:
            query_iterator, _ = self.retry_strategy.execute_with_retry(
                _execute_query,
                f"query_partition_{pk_value}"
            )

            for page in query_iterator.by_page():
                page_count += 1
                items = list(page)
                ru_charge = self._extract_ru_charge(
                    self.container.client_connection.last_response_headers
                )
                total_rus += ru_charge
                self.ru_manager.consume(ru_charge)
                all_items.extend(items)

            duration = time.time() - start_time
            stats = {
                'partition_value': pk_value,
                'doc_count': len(all_items),
                'duration_seconds': duration,
                'actual_rus': total_rus,
                'page_count': page_count
            }
            return all_items, stats

        except Exception as e:
            return [], {
                'partition_value': pk_value,
                'error': str(e),
                'doc_count': 0,
                'actual_rus': total_rus
            }

    def read_all_parallel(self, pk_path: str) -> Tuple[List, List[Dict]]:
        all_docs = []
        all_stats = []
        total_partitions = len(self.partition_values)

        for batch_start in range(0, total_partitions, self.max_parallel):
            batch_end = min(batch_start + self.max_parallel, total_partitions)
            batch = self.partition_values[batch_start:batch_end]

            batch_docs = []
            batch_stats = []

            for pk_value in batch:
                docs, stats = self.read_partition(pk_value, pk_path)
                batch_docs.extend(docs)
                batch_stats.append(stats)

            all_docs.extend(batch_docs)
            all_stats.extend(batch_stats)

        return all_docs, all_stats


def extract_arrays_iterative_optimized(doc, doc_index: int = 0, total_docs: int = 0):

    parent_fields = {}
    child_tables = {}
    root_rid = doc.get("_rid") or str(uuid.uuid4())
    doc["_rid"] = root_rid

    queue = deque()

    def flatten_no_arrays(d, parent=""):
        flat = {}
        for k, v in d.items():
            key = f"{parent}.{k}" if parent else k
            if isinstance(v, list):
                flat[key] = v
            elif isinstance(v, dict):
                flat.update(flatten_no_arrays(v, key))
            else:
                flat[key] = v
        return flat

    flat_root = flatten_no_arrays(doc)

    # Top-level arrays: use FULL dotted key as table_name (Option A)
    for key, value in flat_root.items():
        if not isinstance(value, list):
            parent_fields[key] = value
            continue

        primitive_items = [v for v in value if not isinstance(v, dict)]
        dict_items = [v for v in value if isinstance(v, dict)]

        if primitive_items and not dict_items:
            parent_fields[key] = value
            continue

        for item in dict_items:
            item_rid = str(uuid.uuid4())
            item["_rid"] = item_rid
            item["_parent_rid"] = root_rid

            # *** Key change here: use full dotted path ***
            table_name = key               # e.g. 'order.items', 'payment.history'
            queue.append((item, table_name, root_rid))

    batch_size = 100
    current_batch = {}

    while queue:
        current, table_name, parent_rid = queue.popleft()
        flat = flatten_no_arrays(current)
        row = {"_rid": current["_rid"], "_parent_rid": parent_rid}

        for key, value in flat.items():
            if not isinstance(value, list):
                row[key] = value
                continue

            primitive_items = [v for v in value if not isinstance(v, dict)]
            dict_items = [v for v in value if isinstance(v, dict)]

            if primitive_items and not dict_items:
                row[key] = value
                continue

            for item in dict_items:
                item_rid = str(uuid.uuid4())
                item["_rid"] = item_rid
                item["_parent_rid"] = current["_rid"]

                # nested_table_name extends the full dotted parent path
                nested_table_name = f"{table_name}.{key.split('.')[-1] if '.' in key else key}"
                queue.append((item, nested_table_name, current["_rid"]))

        if table_name not in current_batch:
            current_batch[table_name] = []
        current_batch[table_name].append(row)

        if len(current_batch.get(table_name, [])) >= batch_size:
            if table_name not in child_tables:
                child_tables[table_name] = []
            child_tables[table_name].append(pd.DataFrame(current_batch[table_name]))
            current_batch[table_name] = []

    for table_name, rows in current_batch.items():
        if rows:
            if table_name not in child_tables:
                child_tables[table_name] = []
            child_tables[table_name].append(pd.DataFrame(rows))

    final_children = {}
    for k, v in child_tables.items():
        try:
            final_children[k] = pd.concat(v, ignore_index=True)
        except ValueError:
            final_children[k] = pd.DataFrame(v)

    return parent_fields, final_children


def clean_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or df.empty:
        return pd.DataFrame()

    def fix_value(val):
        if val is None:
            return None
        if isinstance(val, (str, int, float, bool)):
            return val
        if isinstance(val, list) and all(not isinstance(i, dict) for i in val):
            return val
        if isinstance(val, dict):
            return None
        if isinstance(val, list) and any(isinstance(i, dict) for i in val):
            return None
        try:
            return str(val)
        except Exception:
            return None

    for col in df.columns:
        df[col] = df[col].apply(fix_value)

    return df


def upload_csv_to_adls(service_client, file_system, directory, file_name, df):
    df = clean_dataframe(df)
    if df is None or df.empty:
        return

    fs_client = service_client.get_file_system_client(file_system)
    dir_segments = directory.strip("/").split("/") if directory else []
    curr = ""

    for seg in dir_segments:
        curr = f"{curr}/{seg}" if curr else seg
        try:
            fs_client.get_directory_client(curr).create_directory()
        except Exception:
            pass

    dir_client = fs_client.get_directory_client(directory)
    try:
        file_client = dir_client.get_file_client(file_name)
        file_client.delete_file()
    except Exception:
        pass

    df_out = df.copy()

    def serialize_cell(v):
        if v is None:
            return ""
        if isinstance(v, list):
            try:
                return json.dumps(v, ensure_ascii=False)
            except Exception:
                return str(v)
        return v

    for col in df_out.columns:
        df_out[col] = df_out[col].apply(serialize_cell)

    csv_buffer = StringIO()
    df_out.to_csv(csv_buffer, index=False, sep="|")
    content = csv_buffer.getvalue()

    file_client = dir_client.create_file(file_name)
    file_client.append_data(content, offset=0, length=len(content))
    file_client.flush_data(len(content))


@app.activity_trigger(input_name="params")
def process_cosmos_to_adls_activity(params: dict):
    start_time = datetime.utcnow()

    try:
        cosmos_url = params.get("cosmos_url")
        cosmos_key = params.get("cosmos_key")
        cosmos_db = params.get("cosmos_db")
        cosmos_container = params.get("cosmos_container")
        partition_key_path = params.get("partition_key_path")
        partition_key_values = params.get("partition_key_value")
        adls_account_name = params.get("adls_account_name")
        adls_account_key = params.get("adls_account_key")
        adls_file_system = params.get("adls_file_system")
        adls_directory = params.get("adls_directory", "")

        if not all([cosmos_url, cosmos_key, cosmos_db, cosmos_container,
                    adls_account_name, adls_account_key, adls_file_system]):
            return {"status": "error", "message": "Missing required parameters"}

        client = CosmosClient(cosmos_url, credential=cosmos_key)
        database = client.get_database_client(cosmos_db)
        container = database.get_container_client(cosmos_container)

        user_provided_both = bool(partition_key_path) and bool(partition_key_values)

        if user_provided_both:
            pk_path = partition_key_path
            if isinstance(partition_key_values, str):
                try:
                    pk_values = json.loads(partition_key_values)
                except Exception:
                    pk_values = [partition_key_values]
            elif not isinstance(partition_key_values, list):
                pk_values = [partition_key_values]
            else:
                pk_values = partition_key_values

        else:
            throughput_info = CosmosMetadata.get_throughput_info(database, cosmos_container)
            pk_path = CosmosMetadata.get_partition_key_path(container)

            if not pk_path:
                items = list(container.query_items(
                    query="SELECT * FROM c",
                    enable_cross_partition_query=True
                ))
                all_docs = items
                pk_values = []
            else:
                pk_values = CosmosMetadata.discover_partition_values(container, pk_path)

                if not pk_values:
                    items = list(container.query_items(
                        query="SELECT * FROM c",
                        enable_cross_partition_query=True
                    ))
                    all_docs = items
                else:
                    reader = OptimizedParallelCosmosReader(
                        container,
                        throughput_info['throughput'],
                        pk_values
                    )
                    all_docs, partition_stats = reader.read_all_parallel(pk_path)

        if user_provided_both:
            all_docs = []
            key_path_parts = [k for k in pk_path.strip("/").split("/") if k]
            cosmos_key_path = "c." + ".".join(key_path_parts)

            for pk_val in pk_values:
                query = f"SELECT * FROM c WHERE {cosmos_key_path} = @value"
                items = list(container.query_items(
                    query=query,
                    parameters=[{"name": "@value", "value": pk_val}],
                    enable_cross_partition_query=True
                ))
                all_docs.extend(items)

        if not all_docs:
            return {"status": "success", "message": "No documents found.", "docs_processed": 0}

        parent_records = []
        all_child_tables = {}

        for idx, doc in enumerate(all_docs, 1):
            parent, children = extract_arrays_iterative_optimized(doc, idx, len(all_docs))
            parent_records.append(parent)

            for arr_name, df in children.items():
                if arr_name not in all_child_tables:
                    all_child_tables[arr_name] = []
                all_child_tables[arr_name].append(df)

        parent_df = pd.DataFrame(parent_records)

        merged_child_dfs = {}
        for k, v in all_child_tables.items():
            try:
                merged_child_dfs[k] = pd.concat(v, ignore_index=True)
            except ValueError:
                merged_child_dfs[k] = pd.DataFrame(v)

        service_client = DataLakeServiceClient(
            account_url=f"https://{adls_account_name}.dfs.core.windows.net",
            credential=adls_account_key
        )

        export_dir = f"{adls_directory}/{cosmos_container}" if adls_directory else cosmos_container

        upload_csv_to_adls(service_client, adls_file_system, export_dir,
                           f"{cosmos_container}.csv", parent_df)

        uploaded_children = 0
        for arr_name, df in merged_child_dfs.items():
            df = clean_dataframe(df)
            if df is None or df.empty:
                continue

            # arr_name is now full dotted path, e.g. "order.items.discounts"
            path_parts = arr_name.split(".")
            folder_path = "/".join(path_parts)
            file_name = f"{path_parts[-1]}.csv"
            final_dir = f"{export_dir}/{folder_path}"

            upload_csv_to_adls(service_client, adls_file_system, final_dir, file_name, df)
            uploaded_children += 1

        end_time = datetime.utcnow()
        duration = (end_time - start_time).total_seconds()

        summary = {
            "status": "success",
            "docs_processed": len(all_docs),
            "parent_rows": len(parent_df),
            "child_tables_created": len(merged_child_dfs),
            "child_tables_uploaded": uploaded_children,
            "duration_seconds": duration,
            "auto_detected": not user_provided_both,
            "partition_count": len(pk_values) if pk_values else 0
        }

        return summary

    except Exception as e:
        return {"status": "error", "message": str(e)}


@app.orchestration_trigger(context_name="context")
def cosmos_to_adls_orchestrator(context: df.DurableOrchestrationContext):
    params = context.get_input()
    result = yield context.call_activity("process_cosmos_to_adls_activity", params)
    return result


@app.route(route="Cosmos_to_ADLS", methods=["POST"])
@app.durable_client_input(client_name="client")
async def cosmos_to_adls_http_start(req: func.HttpRequest, client) -> func.HttpResponse:
    try:
        body = req.get_json()
        instance_id = await client.start_new("cosmos_to_adls_orchestrator", None, body)
        return client.create_check_status_response(req, instance_id)
    except Exception as e:
        return func.HttpResponse(f"Error: {str(e)}", status_code=500)
